import "GameAdmin.scss";
export default function GameAdmin() {
    return (
        <div className="game_wrap" id="GAME-ADMIN">
          <h3> Hello World</h3>
        </div>
    )
}
