import SwiperComponent from "../components/SwiperComponent";
export default function Home(){
    return(
        <>
        <div style={{marginTop:"50px"}}></div>
        <SwiperComponent></SwiperComponent>
        </>
    )
}
